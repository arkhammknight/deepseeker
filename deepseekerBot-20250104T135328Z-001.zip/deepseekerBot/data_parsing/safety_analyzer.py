"""
Combined safety analyzer using data from multiple sources.

This module combines data from DexScreener and Rugcheck.xyz to provide
comprehensive token safety analysis.
"""

import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass
from .dexscreener_client import DexScreenerClient
from .rugcheck_client import RugcheckClient, RugcheckResult

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class SafetyAnalysis:
    """Combined safety analysis results."""
    token_address: str
    is_safe: bool
    risk_level: str
    risk_factors: List[str]
    dex_data: Dict
    rugcheck_data: RugcheckResult
    timestamp: datetime
    recommendation: str

class SafetyAnalyzer:
    """Analyzer combining multiple data sources for comprehensive safety analysis."""

    def __init__(self, rugcheck_api_key: Optional[str] = None):
        """
        Initialize the safety analyzer.

        Args:
            rugcheck_api_key: Optional API key for Rugcheck.xyz
        """
        self.dex_client = DexScreenerClient()
        self.rugcheck_client = RugcheckClient(rugcheck_api_key)
        self.analysis_cache = {}
        self.bundled_tokens = set()

    async def __aenter__(self):
        """Set up API clients."""
        await self.dex_client.__aenter__()
        await self.rugcheck_client.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Clean up API clients."""
        await self.dex_client.__aexit__(exc_type, exc_val, exc_tb)
        await self.rugcheck_client.__aexit__(exc_type, exc_val, exc_tb)

    async def analyze_token(self, token_address: str) -> SafetyAnalysis:
        """
        Perform comprehensive token safety analysis.

        Args:
            token_address: Token address to analyze

        Returns:
            SafetyAnalysis: Combined analysis results
        """
        try:
            # Check if token is in bundled list
            if token_address in self.bundled_tokens:
                return self._create_bundled_token_analysis(token_address)

            # Get data from both sources
            dex_data = await self.dex_client.get_token(token_address)
            rugcheck_result = await self.rugcheck_client.check_token(token_address)

            # Get bundled tokens and update set
            bundled = await self.rugcheck_client.get_bundled_tokens(token_address)
            self.bundled_tokens.update(bundled)

            # Combine analysis
            risk_factors = []
            risk_factors.extend(rugcheck_result.risk_factors)
            
            # Add DEX-based risk factors
            if dex_data:
                dex_risk_factors = self._analyze_dex_data(dex_data)
                risk_factors.extend(dex_risk_factors)

            # Determine combined risk level
            risk_level = self._determine_risk_level(
                rugcheck_result.risk_level,
                dex_risk_factors if dex_data else []
            )

            # Generate recommendation
            recommendation = self._generate_recommendation(
                risk_level,
                risk_factors,
                rugcheck_result,
                dex_data
            )

            analysis = SafetyAnalysis(
                token_address=token_address,
                is_safe=risk_level in ['SAFE', 'MEDIUM'],
                risk_level=risk_level,
                risk_factors=risk_factors,
                dex_data=dex_data or {},
                rugcheck_data=rugcheck_result,
                timestamp=datetime.now(),
                recommendation=recommendation
            )

            # Cache the analysis
            self.analysis_cache[token_address] = analysis

            return analysis

        except Exception as e:
            logger.error(f"Error in safety analysis: {str(e)}")
            return self._create_error_analysis(token_address, str(e))

    def _analyze_dex_data(self, dex_data: Dict) -> List[str]:
        """
        Analyze DEX data for risk factors.

        Args:
            dex_data: Data from DexScreener

        Returns:
            List[str]: Identified risk factors
        """
        risk_factors = []

        # Check liquidity
        liquidity = float(dex_data.get('liquidity', {}).get('usd', 0))
        if liquidity < 10000:  # Less than $10k liquidity
            risk_factors.append(f"Low liquidity: ${liquidity:,.2f}")

        # Check volume
        volume_24h = float(dex_data.get('volume', {}).get('h24', 0))
        if volume_24h < 1000:  # Less than $1k daily volume
            risk_factors.append(f"Low volume: ${volume_24h:,.2f} 24h")

        # Check price impact
        price_impact = float(dex_data.get('priceImpact', {}).get('buy1000', 0))
        if price_impact > 0.05:  # More than 5% impact for $1000 buy
            risk_factors.append(f"High price impact: {price_impact*100:.1f}%")

        return risk_factors

    def _determine_risk_level(self, 
                            rugcheck_risk: str, 
                            dex_risks: List[str]) -> str:
        """
        Determine combined risk level.

        Args:
            rugcheck_risk: Risk level from Rugcheck
            dex_risks: Risk factors from DEX analysis

        Returns:
            str: Combined risk level
        """
        if rugcheck_risk == 'CRITICAL':
            return 'CRITICAL'
        
        if rugcheck_risk == 'HIGH' or len(dex_risks) >= 2:
            return 'HIGH'
        
        if rugcheck_risk == 'MEDIUM' or len(dex_risks) == 1:
            return 'MEDIUM'
        
        return 'SAFE'

    def _generate_recommendation(self,
                               risk_level: str,
                               risk_factors: List[str],
                               rugcheck_result: RugcheckResult,
                               dex_data: Dict) -> str:
        """
        Generate recommendation based on analysis.

        Args:
            risk_level: Overall risk level
            risk_factors: List of risk factors
            rugcheck_result: Results from Rugcheck
            dex_data: Data from DexScreener

        Returns:
            str: Detailed recommendation
        """
        if risk_level == 'CRITICAL':
            return "AVOID: Critical security risks detected. Do not interact with this token."
        
        if risk_level == 'HIGH':
            return f"HIGH RISK: Multiple concerns detected: {', '.join(risk_factors)}"
        
        if risk_level == 'MEDIUM':
            return f"CAUTION: Some risk factors present: {', '.join(risk_factors)}"
        
        return "SAFE: No significant risk factors detected. Always do your own research."

    def _create_bundled_token_analysis(self, token_address: str) -> SafetyAnalysis:
        """
        Create analysis for bundled token.

        Args:
            token_address: Token address

        Returns:
            SafetyAnalysis: Analysis indicating bundled token
        """
        return SafetyAnalysis(
            token_address=token_address,
            is_safe=False,
            risk_level='HIGH',
            risk_factors=['Token is part of a token bundle - potential scam'],
            dex_data={},
            rugcheck_data=self.rugcheck_client._create_error_result(
                token_address, "Bundled token"
            ),
            timestamp=datetime.now(),
            recommendation="AVOID: Token is part of a suspicious token bundle"
        )

    def _create_error_analysis(self, 
                             token_address: str, 
                             error_message: str) -> SafetyAnalysis:
        """
        Create error analysis result.

        Args:
            token_address: Token address
            error_message: Error message

        Returns:
            SafetyAnalysis: Error analysis result
        """
        return SafetyAnalysis(
            token_address=token_address,
            is_safe=False,
            risk_level='UNKNOWN',
            risk_factors=[f"Analysis error: {error_message}"],
            dex_data={},
            rugcheck_data=self.rugcheck_client._create_error_result(
                token_address, error_message
            ),
            timestamp=datetime.now(),
            recommendation="Unable to complete safety analysis due to error"
        )

    def get_cached_analysis(self, token_address: str) -> Optional[SafetyAnalysis]:
        """
        Get cached analysis for a token.

        Args:
            token_address: Token address to check

        Returns:
            Optional[SafetyAnalysis]: Cached analysis if available
        """
        return self.analysis_cache.get(token_address)

    def clear_cache(self) -> None:
        """Clear all cached data."""
        self.analysis_cache.clear()
        self.bundled_tokens.clear()
        self.dex_client.clear_cache()
        self.rugcheck_client.clear_cache()
