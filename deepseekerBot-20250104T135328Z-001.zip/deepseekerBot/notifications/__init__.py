"""
Notifications module for managing Telegram bot interactions and user alerts.
"""
